package com.cg.project.SignUpServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SignUpServlet
 */
@WebServlet("/SignUp")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		out.print("<html><head><title>Insert title here</title></head><body><form><table><tr><td>Associate ID* :</td><td><input type='text' name='Associate ID' maxlength='20' Placeholder='Associate ID' required></td></tr>");
		out.print("<tr><td>First Name* :</td><td><input type='text' name='First Name' maxlength='20'  Placeholder='First Name' required></td></tr><tr><td>Last Name* :</td><td><input type='text' name='Last Name' Placeholder='Last Name' required></td></tr><tr><td>Department Name* :</td><td><input type='text' name='Department Name' Placeholder='Department Name'></td></tr><tr><td>Designation* :</td><td><input type='text' name='Designation' Placeholder='Designation' required></td></tr>");
		out.print("<tr>
				<td>
					Date of Birth* :
				</td>
				<td>
					<input type='date' name='DOB' required>
				</td>
			</tr>
			<tr>
				<td>
					Username* :
				</td>
				<td>
					<input type='text' name='Username ' required>
				</td>
			</tr>
			<tr>
				<td>
					Password* :
				</td>
				<td>
					<input type='password' name='Password' required>
				</td>
			</tr>
			<tr>
				<td>
					Hobbies :
				</td>
				<td>
					<input type='Text' name='Hobbies'>
				</td>
			</tr>
			<tr>
				<td>
					gender:
				</td>
			<td>
				<input type='radio' name='gender' value='male' checked>male<br>
				<input type='radio' name='gender' value='female' >female<br>
				<input type='radio' name='gender' value='other' >other<br>
			</td>
			</tr>
			<tr>
			<td>
			Graduation :
			</td>
			<td>
			 <input list='Graduation'>
			<datalist id='Graduation'>
			<option value='B.tech'>
			<option value='B.Com'>
			<option value='B.SC'>
			<option value='B.BA'>
			<option value='B.CA'></datalist></td></tr><tr><td>E mail* :</td><td><input type='email' name='email' required></td></tr><tr><td>Age* :</td><td><input type='number' name='Age' required></td></tr><tr><td>Address* :</td><td><input type='text' name='Address' required></td></tr><tr><td>Pincode*:</td><td><input type='number' name='Pincode' maxlength='6' required></td></tr><tr><td>State* :</td><td><input type='text' name='State' required></td></tr><tr><td>Country* :</td><td><input type='text' name='Country' required></td></tr><tr><td>Resume*:</td><td><input type='file' name='Resume' required></td></tr></table><input type='submit' value='submit'><br><input type='Reset' value='Reset'></form></body></html>");
		
	}

}
