package com.cg.project.RegistrationServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/Registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String associateId=request.getParameter("associateID");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String departmentName=request.getParameter("departmentName");
		String designation = request.getParameter("designation");
		String userName= request.getParameter("userName");
		String password=request.getParameter("password");
		String[] hobbies = request.getParameterValues("hobbies");
		String gender = request.getParameter("gender");
		String email=request.getParameter("email");
		String age=request.getParameter("age");
		String address=request.getParameter("address");
		String pincode=request.getParameter("pincode");
		String state=request.getParameter("state");
		String country=request.getParameter("country");
		
		PrintWriter out=response.getWriter();
		out.print("<html><body>");
		out.print("<div align='center'><font color=red size=8>User Details</font></div>");
		out.println("Associate Id :"+associateId+"<br>");
		out.println("First Name :"+firstName+"<br>");
		out.println("Last Name :"+lastName+"<br>");
		out.println("Department Name :"+departmentName+"<br>");
		out.println("Designation :"+designation+"<br>");
		out.println("UserName:"+userName+"<br>");
		out.println("Password :"+password+"<br>");
		out.println("Gender :"+gender+"<br>");
		out.println("Email:"+email+"<br>");
		out.println("Age :"+age+"<br>");
		out.println("Address:"+address+"<br>");
		out.println("PinCode :"+pincode+"<br>");
		out.println("State :"+state+"<br>");
		out.println("Country:"+country+"<br>");
		out.println("Your Hobbies are");
		
		for(String hob:hobbies)
			out.print(hob+" ");
		out.println("</body></html>");
	}
}
