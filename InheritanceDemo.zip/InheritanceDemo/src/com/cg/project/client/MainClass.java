package com.cg.project.client;

import com.cg.project.beans.Employee;
import com.cg.project.beans.Pemployee;

public class MainClass {

	public static void main(String[] args) {
		Employee emp=new Employee(101, 15000, "Satish", "Mahajan");
		emp.calculateTotalSalary();
		
		System.out.println(emp.toString());
		
		Pemployee pemp=new Pemployee(102, 20000, "Nitika", "Garg");
		
		pemp.calculateTotalSalary();
		System.out.println(pemp.toString());

	}

}
