package com.cg.banking.beans;

public class Address {

}
