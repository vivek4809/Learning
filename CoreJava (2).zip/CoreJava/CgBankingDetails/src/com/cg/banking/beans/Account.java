package com.cg.banking.beans;

public class Account {
  private int 	accountNo ,accountBalance ;
 private String  privateaccountType ;

}
