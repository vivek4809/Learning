package com.cg.payroll.client;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
public class MainClass {

	public static void main(String[] args) {
		int num=100;

		Associate associate1= new Associate(101, 15000, "Satish", "Mahajan", "Sr.Con", "YTP", "JDDU2664", "satish@gmail.com",new BankDetails(12345, "HDFC", "HDFC00007"),new  Salary(15000, 200, 200, 200));
		Associate associate2 = new Associate(	102, 15000, "Rajesh", "Mahajan", "Sr.Con", "YTP", "UDIDI737", "rajesh@gmail.com",new BankDetails(13456," HDFC", "HDFC00007"));
		
		//System.out.println("FullName:="+associate1.getFirstname()+" "+associate1.getLastname());
		
		/*BankDetails bankDetails1 = new BankDetails(2345, "HDFC"," HDFC000007");
		BankDetails bankDetails2 = new BankDetails(1245, "HDFC"," HDFC000007");
		
		
		System.out.println(Associate.getASSOCIATE_COUNTER() );*/
		
		associate1.getSalary().setHra(30*associate1.getSalary().getBasicSalary()/100);
		associate1.getSalary().setOtherAllowance(20*associate1.getSalary().getBasicSalary()/100);
		associate1.getSalary().setPersonalAllowance(25*associate1.getSalary().getBasicSalary()/100);
		associate1.getSalary().setConveyenceAllowance(25*associate1.getSalary().getBasicSalary()/100);
	}

}
