package com.cg.payroll.beans;

public class BankDetails {
	private int accountNumber;
	private String bankname ,ifscCode;
	
	public BankDetails(int accountNumber, String bankname, String ifscCode) {
		super();
		this.accountNumber = accountNumber;
		this.bankname = bankname;
		this.ifscCode = ifscCode;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	
}
