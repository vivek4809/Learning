
public class BinaryDecimal {

	public static void main(String[] args) {
		int

	}

}
