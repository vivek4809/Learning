
public class NoofOddEven {

	public static void main(String[] args) {
		int even=0,odd=0;
		int a[]={10,13,15,14,26,25,45,46,47,50};
		for(int i=0;i<10;i++){
			if(a[i]%2==0)
				even++;
			else
				odd++;
		}
		System.out.println("The number of even numbers are   "+even);
		System.out.println("The number of odd numbers are   "+odd);

	}

}
