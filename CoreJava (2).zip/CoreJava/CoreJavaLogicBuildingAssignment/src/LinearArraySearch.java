
public class LinearArraySearch {
	public static void main(String[] args) {
		int numList[]={2,4,6,8,10,12,14,16,18,20};
		int count=0,search=8,a=0;
		for(int i=0;i<=9;i++){
			if(numList[i]==search){
				count=1;
				a=i+1;
				break;
			}	
		}
		if(count==1)
			System.out.println("The number is present at position "+ a );
		else
			System.out.println("The number is not present ");	

	}

}
