
public class PalindromeStatus {

	public static void main(String[] args) {
		int num=1245421,temp=num,reverse=0;
		while(temp!=0)
		{
			reverse=reverse*10;
			reverse=reverse+temp%10;
			temp=temp/10;
			}
	if(num==reverse)
		System.out.println("The entered number is Palindrome");
	else
		System.out.println("The entered number is not Palindrome");
	}

}
