public class DecimalToBinary {

	public static void main(String[] args) {
		int binary[]=new int[50];
		int decNum=18,i= 0; 
		while (decNum > 0){ 
			binary[i]=decNum%2; 
			decNum =decNum /2; 
			i++;
		}
		for(int j=i-1;j>=0;j--){
			System.out.print(binary[j]);
		} 
	}
}