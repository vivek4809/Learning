
public class Swap {

	public static void main(String[] args) {
		int a=2,b=4;
		System.out.println("Numbers to swap are a="+a+" b="+b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("After swapping a="+a+" b="+b);

	}

}
