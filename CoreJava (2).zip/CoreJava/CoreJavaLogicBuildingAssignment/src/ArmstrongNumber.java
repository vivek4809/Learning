import java.math.*;
public class ArmstrongNumber {

	public static void main(String[] args) {
		int num=8208,temp=num,digitscount=4,r;
		double c=0;
		while(temp!=0)
		{
			r=temp%10;
			c+=Math.pow(r,digitscount);
			temp=temp/10;
		}
		if(c==num)
			System.out.println("The entered number is a Armstrong number");
		else 
			System.out.println("The number entered is not an armstrong");
	}

}
