
public class MainClass {

	public static void main(String[] args) {
		Address address = new Address("Pune", "Maharashtra", "India", 4012011);
		Customer customer = new Customer(101, "Satish", "Mahajan", address);
/*Address.address2=customer.getAddress();
 * System.out.println(address2.getCity());
 */
		
		System.out.println(customer.getAddress().getCity());
		/* customer.getAddress().setCountry("NewCountry");
		 * customer.getAddress().setCity("NewCity");
		 * customer.getAddress().setstate("NewState");
		 */
		customer.setAddress(new Address("mumbai", "Maharashtra", "India", 147001));
		System.out.println(customer.getAddress().getCity());
	}

}
