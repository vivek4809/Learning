package com.cg.mobilebilling.client;

import java.time.Month;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

public class MainClass {
	private static ApplicationContext context = new ClassPathXmlApplicationContext("projectbeans.xml");
	private static BillingServices billingServices = (BillingServices) context.getBean("billingServices");
	public static void main(String[] args) {
		
		/*try {
			System.out.println("Your customer  ID is: " + billingServices.acceptCustomerDetails("Ayush", "Goel", "ag@gmail.com", "Jan 24 2018", "Delhi", "Delhi", 110007));
			
			
		} catch (BillingServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		/*List<Plan> plans = billingServices.getPlanAllDetails();
		System.out.println("Printing All Plans");
		for (Plan plan : plans) {
			System.out.println(plan.toString());
		}*/
		
		/*try {
//			billingServices.openPostpaidMobileAccount(20001, 1001, 9990964681L);
//			billingServices.openPostpaidMobileAccount(20001, 1002, 9990964681L);
			billingServices.openPostpaidMobileAccount(20025, 1007, 8725831845L);
//			billingServices.openPostpaidMobileAccount(20025, 1007, 9990964681L);
		} catch (PlanDetailsNotFoundException | CustomerDetailsNotFoundException | BillingServicesDownException e) {
			System.err.println(e.getMessage());
		}*/
		
		/*try {
			System.out.println("yoyo");
			System.out.println(billingServices.generateMonthlyMobileBill(20001, 9990964681L, Month.JANUARY.toString() , 175, 115, 255, 125, 800))c;
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | InvalidBillMonthException
				| BillingServicesDownException | PlanDetailsNotFoundException e) {
			System.err.println(e.getMessage());
		}*/
		
		/*try {
			System.out.println(billingServices.getCustomerDetails(20001));
		} catch (CustomerDetailsNotFoundException | BillingServicesDownException e) {
			System.err.println(e.getMessage());
		}*/
		
		/*try {
			List<Customer> customers = billingServices.getAllCustomerDetails();
			for (Customer customer : customers) {
				System.out.println(customer.toString());
			}
		} catch (BillingServicesDownException e) {
			System.err.println(e.getMessage());
		}*/
		
		/*try {
			System.out.println(billingServices.getPostPaidAccountDetails(20001, 9990964681L));
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | BillingServicesDownException e) {
			System.err.println(e.getMessage());
		}*/
		
		/*try {
			List<PostpaidAccount> accounts = billingServices.getCustomerAllPostpaidAccountsDetails(20001);
			for (PostpaidAccount postpaidAccount : accounts) {
				System.out.println(postpaidAccount);
			}
		} catch (CustomerDetailsNotFoundException | BillingServicesDownException e) {
			 System.err.println(e.getMessage());
		}*/
		
		/*try {
			System.out.println(billingServices.openPostpaidMobileAccount(20021, 1002, 9990964681L));
		} catch (PlanDetailsNotFoundException | CustomerDetailsNotFoundException | BillingServicesDownException e) {
			System.err.println(e.getMessage());
		}*/
		
		/*try {
			billingServices.changePlan(20021, 9990964681L, 1004);
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | PlanDetailsNotFoundException
				| BillingServicesDownException e) {
			System.err.println(e.getMessage());
		}*/
		
		try {
			billingServices.closeCustomerPostPaidAccount(20025, 8725831845L);
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | BillingServicesDownException e) {
			System.err.println(e.getMessage());
		}
		
		/*try {
			billingServices.deleteCustomer(20023);
		} catch (BillingServicesDownException | CustomerDetailsNotFoundException e) {
			System.err.println(e.getMessage());
		}*/
	} 
}